<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../styles/style.css">
    <link rel="stylesheet" href="../styles/pagcat.css">
    <style>
            .preço {
                font-family: Arial, Helvetica, sans-serif;
                font-weight: 900;
                font-size: 18px;
                position: absolute;
                bottom: 10px;
                left: 45%; 
                transform: translateX(-50%);
            }
    </style>
</head>
<body>
<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="https://www.instagram.com/_.gabrielnunes_/">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="../imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="paglogin.php"><img style="height: 20px; width: 20px;" src="../imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="paglogin.php">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="../pagprincipal.php"><img src="../imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="../pagprincipal.php">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="../pagprodutos.php"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagservicos.php"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagrecomendacoes.php"><strong>RECOMENDAÇÕES</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href=""><button class="butheader3"><img class="cbgheader" src="../imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>
<div id="divcat">
    <div id="divBusca">
        <input type="text" id="txtBusca" placeholder="Procurar Produtos ou Serviços" />
        <img src="../imgs/search3.png" id="btnBusca" alt="Buscar" />
    </div>
</div>


    <h1>SABONETES FACIAIS</h1>

    <main>
    <div class="container">
        <div class="img-wraper">
            <a href="../pagvend/gel-limpeza-skin-100g-eudora.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial1eudorapo.jpg" alt="">
                <span>Gel de Limpeza Skin 100g (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/actine-sabonete-liquido-vit-c-240g-darrow.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial2darrowpo.png" alt="">
                <span>Actine Sabonete Líquido + Vit C - Laranja 240g (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/gel-limpeza-acido-salicilico-glicerina-350g-principia.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial3principiapo.png" alt="">
                <span>Gel de Limpeza 2% Ácido Salicílico + 5% Glicerina 350g (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/gel-limpeza-suave-antioleosidade-100ml-creamy.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial4creamypo.png" alt="">
                <span>Gel de limpeza suave antioleosidade 100ml (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/limpador-antiolesidade-300ml-sallve.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial5sallvepo.png" alt="">
                <span>Limpador antioleosidade 300 ml (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/gel-limpeza-gl02-350g-principia.php">
                <img class="imgprod" src="../imgs/produtos/pele_mista/sbfacial2darrow.png" alt="">
                <span>Gel de Limpeza GL-02 350G (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/limpador-facial-300ml-sallve.php">
                <img class="imgprod" src="../imgs/produtos/pele_sensivel/sbfacial4sallve.png" alt="">
                <span>Limpador facial (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="../sabonete-liquido-facial-darrow-peles-sensiveis.php">
                <img class="imgprod" src="../imgs/produtos/pele_sensivel/sbfacial1darrow.png" alt="">
                <span>Sabonete Líquido Facial Darrow Suavie Peles Sensíveis e Sensibilizadas 140ml (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/limpador-glicerinado-200ml-creamy.php">
                <img class="imgprod" src="../imgs/produtos/pele_sensivel/sbfacial3creamy.png" alt="">
                <span>Limpador Facial Glicerinado (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

    </div>
    </main>



</body>
</html>