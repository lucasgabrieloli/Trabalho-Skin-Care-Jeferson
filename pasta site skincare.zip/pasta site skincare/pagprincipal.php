
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INÍCIO / Brilho & Glamour</title>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/pagprincipal.css">
    <link rel="stylesheet" href="styles/slider.css">
    <link rel="stylesheet" href="styles/footer.css">
    <script src="js/slide.js" defer></script>
    <style>
        main{
            margin-top: 50px;
            margin-right: 450px;
            margin-left: 710px;
            display: flex;
            flex-direction: column;  
            align-items: center;  
            padding: 15px;
            margin-bottom: 50px;
            box-shadow: 6px 6px 6px rgba(0, 0, 0, 0.2);
            border-radius: 3px;
            background-color: #f39c9c36;
            overflow: hidden;
            }
        .preço {
            font-family: Arial, Helvetica, sans-serif;
            font-weight: 900;
            font-size: 18px;
            position: absolute;
            bottom: 10px;
            left: 45%; 
            transform: translateX(-50%);
        }
        .container{
            margin-bottom: 30px;
        }
    </style>

</head>
<body>

<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="logincad/index.html"><img style="height: 20px; width: 20px;" src="imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="logincad/index.html">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="pagprincipal.php"><img src="imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="pagprincipal.php" style="color: #b73c4a">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="pagprodutos.php"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagservicos.php"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href="carrinho.php"><button class="butheader3"><img class="cbgheader" src="imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>


<div id="divcat">
    <nav>
        <ul class="menu">
            <li>
                <a class="acat" style="background-color: #b73c4a; color: #ffffff; font-family: arial, sans-serif; font-weight: 900;" href="">
                    CATEGORIAS <span class="setinha"></span>
                </a>
                <ul>
                    <li><a class="acat" href="pagcat/sabonetes-faciais.php">SABONETES</a></li>
                    <li><a class="acat" href="pagcat/acidos.php">ÁCIDOS</a></li>
                    <li><a class="acat" href="pagcat/hidratantes.php">HIDRATANTES</a></li>
                    <li><a class="acat" href="pagcat/protetor-solar.php">PROTETOR SOLAR</a></li>
                    <li><a class="acat" href="pagcat/serum.php">SERUM</a></li>
                    <li><a class="acat" href="pagcat/kits.php">KITS</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <div id="divBusca">
        <input type="text" id="txtBusca" placeholder="Procurar Produtos ou Serviços" />
        <img src="imgs/search3.png" id="btnBusca" alt="Buscar" />
    </div>
</div>

    <main>
        <div class="slider">

            <div class="slides">
                <input type="radio" name="radio-btn" id="radio1">
                <input type="radio" name="radio-btn" id="radio2">
                <input type="radio" name="radio-btn" id="radio3">

                <div class="slide first">
                    <img src="imgs/slide/slide1.jpg" alt="">
                </div>
                <div class="slide">
                    <img src="imgs/slide/slide2.jpg" alt="">
                </div>
                <div class="slide">
                    <img src="imgs/slide/slide3bon.jpg" alt="">
                </div>

                <div class="navigation-auto">
                    <div class="auto-btn1"></div>
                    <div class="auto-btn2"></div>
                    <div class="auto-btn3"></div>
                </div>
            </div>

            <div class="manual-navigation">
                <label for="radio1" class="manual-btn"></label>
                <label for="radio2" class="manual-btn"></label>
                <label for="radio3" class="manual-btn"></label>
            </div>
        
        </div>

        <div class="h2dd"><img src="imgs/icons8-bem-estar-64.png" alt="" style="width: 50px; height: 50px; margin-top: 45px;">&emsp;<h2 class="h2m">FAZEMOS SERVIÇOS NA CLÍNICA OU À DOMICÍLIO!</h2></div>
        <div class="h2dd" style="margin-top: 30px;"><img src="imgs/icons8-xampu-100.png" alt="" style="width: 50px; height: 50px; margin-top:45px;"><h2 class="h2m">&emsp;<h2 class="h2m">TEMOS TODO TIPO DE PRODUTO PARA A PELE!</h2></div>
        
        <div class="divlistra"></div>

        <h2 class="h2ma">PRODUTOS MAIS VENDIDOS</h2>
        <div class="container">
        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial1eudorapo.jpg" alt="">
                <span>Gel de Limpeza Skin 100g (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial2darrowpo.png" alt="">
                <span>Actine Sabonete Líquido + Vit C - Laranja 240g (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial3principiapo.png" alt="">
                <span>Gel de Limpeza 2% Ácido Salicílico + 5% Glicerina 350g (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial4creamypo.png" alt="">
                <span>Gel de limpeza suave antioleosidade 100ml (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial5sallvepo.png" alt="">
                <span>Limpador antioleosidade 300 ml (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/sbfacial1eudora.png" alt="">
                <span>Dermo Hidratante (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

    </div>

    
    </main>



   
    <footer>
        <div class="tt">
            <p>@2024 BRILHO E GLAMOUR. TODOS OS DIREITOS RESERVADOS! <a href="">POLÍTICA DE PRIVACIDADE</a></p>
            <p style="font-size: 15px; margin-top:55px;">FEITO POR: JOÃO GABRIEL E LUCAS GABRIEL - 2°A - DS (ETEC JK)</p>
        </div>
        <div class="btzin"></div>
    </footer>
    <script src="js/script.js"></script>
</body>
</html>