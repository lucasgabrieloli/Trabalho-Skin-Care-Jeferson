<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SERVIÇOS / Brilho & Glamour</title>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/pagservicos.css">
    <link rel="stylesheet" href="styles/footer.css">
    <style>
            .preço {
                font-family: Arial, Helvetica, sans-serif;
                font-weight: 900;
                font-size: 18px;
                position: absolute;
                bottom: 10px;
                left: 45%; 
                transform: translateX(-50%);
            }
            .container{
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="https://www.instagram.com/_.gabrielnunes_/">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="logincad/index.html"><img style="height: 20px; width: 20px;" src="imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="logincad/index.html">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="pagprincipal.php"><img src="imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="pagprincipal.php">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="pagprodutos.php"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagservicos.php" style="color: #b73c4a"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href="carrinho.php"><button class="butheader3"><img class="cbgheader" src="imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>

<div id="divcat">
    <div id="divBusca">
        <input type="text" id="txtBusca" placeholder="Procurar Produtos ou Serviços" />
        <img src="imgs/search3.png" id="btnBusca" alt="Buscar" />
    </div>
</div>
    
            <h1>Todos os serviços</h1>
    <main>

    <h3>PELE</h3>

    <div class="container">
        <div class="img-wraper">
            <a href="pagserv/drenagem-linfatica.php">
                <img class="imgprod" src="imgs/servicos/drenlinf.png" alt="">
                <span>Drenagem Linfática</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/massagem-modeladora.php">
                <img class="imgprod" src="imgs/servicos/massmodel.png" alt="">
                <span>Massagem Modeladora</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/peeling-quimico.php">
                <img class="imgprod" src="imgs/servicos/peelquim.png" alt="">
                <span>Peeling Químico</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/microagulhamento.php">
                <img class="imgprod" src="imgs/servicos/microagulhamento.png" alt="">
                <span>Microagulhamento</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/skinbooster.php">
                <img class="imgprod" src="imgs/servicos/skinbooster.png" alt="">
                <span>Skinbooster</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagserv/botox.php">
                <img class="imgprod" src="imgs/servicos/botox.png" alt="">
                <span>Botox</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/harmonizacao-facial.php">
                <img class="imgprod" src="imgs/servicos/harmonizfac.png" alt="">
                <span>Harmonização facial</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/rejuvenescimento-a-laser.php">
                <img class="imgprod" src="imgs/servicos/rejuvelas.png" alt="">
                <span>Rejuvenescimento a laser</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
    </div>

    <h3>CORPO E PELE</h3>
    <div class="container">
        <div class="img-wraper">
            <a href="pagserv/criolipolise.php">
                <img class="imgprod" src="imgs/servicos/criolipolise.png" alt="">
                <span>Criolipólise</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/tratamentos-de-radiofrequencia.php">
                <img class="imgprod" src="imgs/servicos/radio.png" alt="">
                <span>Tratamentos de Radiofrequência</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/laser-fracionado.php">
                <img class="imgprod" src="imgs/servicos/lasfrac.png" alt="">
                <span>Laser fracionado</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagserv/endermoterapia.php">
                <img class="imgprod" src="imgs/servicos/endermoterapia.png" alt="">
                <span>Endermoterapia</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

    </div>

    </main>

    <footer>
        <div class="tt">
            <p>@2024 BRILHO E GLAMOUR. TODOS OS DIREITOS RESERVADOS! <a href="">POLÍTICA DE PRIVACIDADE</a></p>
            <p style="font-size: 15px; margin-top:55px;">FEITO POR: JOÃO GABRIEL E LUCAS GABRIEL - 2°A - DS (ETEC JK)</p>
        </div>
        <div class="btzin"></div>
    </footer>

</body>
</html>