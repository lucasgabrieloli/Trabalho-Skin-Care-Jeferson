<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../styles/style.css">
    <link rel="stylesheet" href="../styles/pagvenda.css">
    <style>
                main{
            margin-top: 50px;
            margin-right: 400px;
            margin-left: 400px;
            display: flex;
            padding: 15px;
            margin-bottom: 50px;
            box-shadow: 6px 6px 6px rgba(0, 0, 0, 0.2);
            border-radius: 3px;
            background-color: #f39c9c36;
            overflow: hidden;
            border-radius: 20px;
            }

    </style>
</head>
<body>
<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="../imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="../logincad/index.html"><img style="height: 20px; width: 20px;" src="../imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="../logincad/index.html">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="pagprincipal.php"><img src="../imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="../pagprincipal.php">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="../pagprodutos.php"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagservicos.php"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href=""><button class="butheader3"><img class="cbgheader" src="../imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>

<main>
        <div class="ppv">
                <img class="imgv" src="../imgs/servicos/peelquim.png" alt=""> 
            <div class="titeprec">
                <h2 style="text-align: center;">Peeling Químico</h2>
                <h3>R$10,00</h3>
                    <div class="listra"></div>
                <!--ADICIONAR BOTAO AQ PARA CARRINHO OU PRA COMPRA-->
                <div class="divbotao">
                    <p style="font-size: 25px;">AGENDAR</p>
                </div>
            </div>            
        </div>
            
            <div class="infoprod">
                <h2 id="titt">Mais informações sobre o serviço</h2>
                <h3 id="titt2">Tratamento estético onde são aplicados ácidos sobre a pele, que ajudam a retirar as camadas danificadas por meio da descamação e a promover o c ju rescimento de uma camada lisa, mais elástica, suave e fresca, por meio da renovação celular. É indicado para renovar a pele, combater a oleosidade e tirar manchas. Os produtos utilizados devem ser adequados ao tipo de pele, bem como a frequência do tratamento

                </h3>
            </div>

            <h2 id="mprod">MAIS SERVIÇOS</h2>

    <div class="container">
        <div class="img-wraper">
            <a href="pagserv/drenagem-linfatica.php">
                <img class="imgprod" src="../imgs/servicos/drenlinf.png" alt="">
                <span>Drenagem Linfática</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/servicos/massmodel.png" alt="">
                <span>Massagem Modeladora</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/servicos/peelquim.png" alt="">
                <span>Peeling Químico</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/servicos/microagulhamento.png" alt="">
                <span>Microagulhamento</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/servicos/skinbooster.png" alt="">
                <span>Skinbooster</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/servicos/botox.png" alt="">
                <span>Botox</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
    </div>

    </main>

</body>
</html>