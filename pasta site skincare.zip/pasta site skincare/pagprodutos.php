<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRODUTOS / Brilho & Glamour</title>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/pagprodutos.css">
    <link rel="stylesheet" href="styles/footer.css">
    <style>
            .preço {
                font-family: Arial, Helvetica, sans-serif;
                font-weight: 900;
                font-size: 18px;
                position: absolute;
                bottom: 10px;
                left: 45%; 
                transform: translateX(-50%);
            }
        .container{
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="https://www.instagram.com/_.gabrielnunes_/">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="logincad/index.html"><img style="height: 20px; width: 20px;" src="imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="logincad/index.html">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="pagprincipal.php"><img src="imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="pagprincipal.php">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="pagprodutos.php" style="color: #b73c4a;"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagservicos.php"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href="carrinho.php"><button class="butheader3"><img class="cbgheader" src="imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>

 
<div id="divcat">
<nav>
        <ul class="menu">
            <li>
                <a class="acat" style="background-color: #b73c4a; color: #ffffff; font-family: arial, sans-serif; font-weight: 900;" href="">
                    CATEGORIAS <span class="setinha"></span>
                </a>
                <ul>
                    <li><a class="acat" href="pagcat/sabonetes-faciais.php">SABONETES</a></li>
                    <li><a class="acat" href="pagcat/acidos.php">ÁCIDOS</a></li>
                    <li><a class="acat" href="pagcat/hidratantes.php">HIDRATANTES</a></li>
                    <li><a class="acat" href="pagcat/protetor-solar.php">PROTETOR SOLAR</a></li>
                    <li><a class="acat" href="pagcat/serum.php">SERUM</a></li>
                    <li><a class="acat" href="pagcat/kits.php">KITS</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <div id="divBusca">
        <input type="text" id="txtBusca" placeholder="Procurar Produtos ou Serviços" onkeyup="search()" name="txtBusca" />
        <img src="imgs/search3.png" id="btnBusca" alt="Buscar" />
    </div>
</div>

    <h1>Todos os produtos</h1>

    <main>
    <h3>SABONETES FACIAIS</h3>
    <div class="container">
        <div class="img-wraper">
            <a href="pagvend/gel-limpeza-skin-100g-eudora.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial1eudorapo.jpg" alt="">
                <span class="nomeprod">Gel de Limpeza Skin 100g (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/actine-sabonete-liquido-vit-c-240g-darrow.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial2darrowpo.png" alt="">
                <span class="nomeprod">Actine Sabonete Líquido + Vit C - Laranja 240g (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/gel-limpeza-acido-salicilico-glicerina-350g-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial3principiapo.png" alt="">
                <span class="nomeprod">Gel de Limpeza 2% Ácido Salicílico + 5% Glicerina 350g (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/gel-limpeza-suave-antioleosidade-100ml-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial4creamypo.png" alt="">
                <span class="nomeprod">Gel de limpeza suave antioleosidade 100ml (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/limpador-antiolesidade-300ml-sallve.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/sbfacial5sallvepo.png" alt="">
                <span class="nomeprod">Limpador antioleosidade 300 ml (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagvend/sabonete-facial-nutriol-240ml-darrow.php">
                <img class="imgprod" src="imgs/produtos/pele_seca/sbfacial2darrow.png" alt="">
                <span class="nomeprod">Sabonete facial líquido Nutriol 240ml (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/limpador-facial-300ml-sallve.php">
                <img class="imgprod" src="imgs/produtos/pele_sensivel/sbfacial4sallve.png" alt="">
                <span class="nomeprod">Limpador facial (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagvend/sabonete-liquido-facial-darrow-peles-sensiveis.php">
                <img class="imgprod" src="imgs/produtos/pele_sensivel/sbfacial1darrow.png" alt="">
                <span class="nomeprod">Sabonete Líquido Facial Suave Peles Sensíveis e Sensibilizadas 140ml (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/gel-limpeza-gl02-350g-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_sensivel/sbfacial2principia.png" alt="">
                <span class="nomeprod">Gel de Limpeza GL-02 350G (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/limpador-glicerinado-200ml-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_sensivel/sbfacial3creamy.png" alt="">
                <span class="nomeprod">Limpador Facial Glicerinado 200ml (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

    </div>

    <h3>ÁCIDOS</h3>

    <div class="container">
        <div class="img-wraper">
            <a href="pagvend/acido-salicilico-90ml-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/acido1creamy.png" alt="">
                <span class="nomeprod">Ácido Salicílico 90ml (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagvend/acido-latico-30ml-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/acido1creamy.png" alt="">
                <span class="nomeprod">Ácido Lático 30ml (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/acido-mandelico-30ml-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/acido2principia.png" alt="">
                <span class="nomeprod">Ácido Mandélico 30ml (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/super-acido-glicolico-10-sallve.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/acido3sallve.png" alt="">
                <span class="nomeprod">Super Ácido Glicólico 10% (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

    </div>

    <h3>HIDRATANTES</h3>

    <div class="container">

        <div class="img-wraper">
            <a href="pagvend/agua-micelar-hidratante-100ml-darrow.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/hidratante2darrow.png" alt="">
                <span class="nomeprod">Água Micelar Hidratante 100ml (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-ultra-light-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/hidratante3principia.png" alt="">
                <span class="nomeprod">Hidratante Facial Ultra Light (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-calmante-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/hidratante4creamy.png" alt="">
                <span class="nomeprod">Hidratante Facial Calmante (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-matte-control-eudora.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/hidratante5eudora.png" alt="">
                <span class="nomeprod">Hidratante Facial Matte Control (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-equilibrio-eudora.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/hidratante1eudora.png" alt="">
                <span class="nomeprod">Hidratante Facial Equilíbrio (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-multipla-acao-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/hidratante2creamy.png" alt="">
                <span class="nomeprod">Hidratante Facial Múltipla Ação (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-equilibrio-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/hidratante3principia.png" alt="">
                <span class="nomeprod">Hidratante Facial Equilíbrio (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-hidratante-equilibrante-sallve.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/hidratante4sallve.png" alt="">
                <span class="nomeprod">Hidratante Facial Hidratante e Equilibrante (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/hidratante-facial-hidratante-controlador-darrow.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/hidratante5darrow.png" alt="">
                <span class="nomeprod">Hidratante Facial Hidratante e Controlador (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        

    </div>

    <h3>PROTETOR SOLAR</h3>

    <div class="container">
        <div class="img-wraper">
            <a href="pagvend/solar-oil-free-fps-50-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/psolar1creamy.png" alt="">
                <span class="nomeprod">Solar Oil Free FPS 50 (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/sun-protection-fps-50-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/psolar2principia.png" alt="">
                <span class="nomeprod">Sun Protection FPS 50 (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/protetor-solar-fps-50-sallve.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/psolar3sallve.png" alt="">
                <span class="nomeprod">Protetor Solar Facial FPS 50 (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/neo-dermo-etage-protetor-solar-fps-50-pele-sensivel-eudora.php">
                <img class="imgprod" src="imgs/produtos/pele_mista/psolar1eudora.png" alt="">
                <span class="nomeprod">Neo Dermo Etage Protetor Solar FPS 50 Pele Sensível (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/sun-discolor-fps-50-darrow.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/psolar4darrow.png" alt="">
                <span class="nomeprod">Sun Discolor FPS 50 (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/protetor-solar-facial-matte-fps-50-eudora.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/hidratante5eudora.png" alt="">
                <span class="nomeprod">Protetor Solar Facial Matte FPS 50 (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
    </div>

    <h3>SÉRUM</h3>

    <div class="container">
        <div class="img-wraper">
            <a href="pagvend/neo-dermo-etage-serum-ultra-purioficante-eudora.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/serum1eudora.png" alt="">
                <span class="nomeprod"> Neo Dermo Etage Sérum Ultra Purificante(Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/actine-tridefense-serum-antiidade-darrow.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/serum2darrow.png" alt="">
                <span class="nomeprod">Actine TriDefense Sérum Anti-Idade(Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/serum-niacinamida-zinco-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/serum3principia.png" alt="">
                <span class="nomeprod">Sérum Niacinamida 10% + Zinco 1% ( Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/serum-acido-mandelico-alfa-arbutin-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/serum4creamy.png" alt="">
                <span class="nomeprod">Sérum Ácido Mandélico 10% + Alfa-Arbutin 2% (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/serum-anti-acne-sallve.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/serum5sallve.png" alt="">
                <span class="nomeprod">Sérum Anti-acne (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

    </div>

    <h3>KITS</h3>

    <div class="container">
        <div class="img-wraper">
            <a href="pagvend/kit-antiacne-avancado-5-produtos-principia.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/kit1principia.png" alt="">
                <span class="nomeprod"> Kit anti-acne Avançado com 5 produtos (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/kit-pele-oleosa-sallve.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/kit2sallve.png" alt="">
                <span class="nomeprod">Kit Pele Oleosa (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagvend/rotina-antiacne-e-antioleosidade-creamy.php">
                <img class="imgprod" src="imgs/produtos/pele_oleosa/kit3creamy.png" alt="">
                <span class="nomeprod">Rotina Anti-Acne e Antioleosidade (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
</main>

<footer>
        <div class="tt">
            <p>@2024 BRILHO E GLAMOUR. TODOS OS DIREITOS RESERVADOS! <a href="">POLÍTICA DE PRIVACIDADE</a></p>
            <p style="font-size: 15px; margin-top:15px;">FEITO POR: JOÃO GABRIEL E LUCAS GABRIEL - 2°A - DS (ETEC JK)</p>
        </div>
        <div class="btzin"></div>
</footer>

<script src="js/script.js"></script>
    
</body>
</html>