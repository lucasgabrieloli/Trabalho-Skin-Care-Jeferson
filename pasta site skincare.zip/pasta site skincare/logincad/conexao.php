<?php
session_start();

if (!isset($_SESSION['idUsuario'])) {
    header("Location: login.html");
    exit();
}

echo "Bem-vindo, " . $_SESSION['nome'] . "!";
?>
