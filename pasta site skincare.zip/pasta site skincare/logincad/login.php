<?php
session_start();
include('conexao.php'); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $email = mysqli_real_escape_string($conn, $email);
    $senha = mysqli_real_escape_string($conn, $senha);

    $sql = "SELECT * FROM usuarios WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($senha, $user['senha'])) {
        $_SESSION['idUsuario'] = $user['idUsuario'];
        $_SESSION['nome'] = $user['nome'];

        header("Location: painel.php");
        exit();
    } else {
        echo "Email ou senha incorretos.";
    }
}
?>
