<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CARRINHO / Brilho & Glamour</title>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/carrinho.css">
    <link rel="stylesheet" href="styles/footer.css">
</head>
<body>
<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="logincad/index.html"><img style="height: 20px; width: 20px;" src="imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="logincad/index.html">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="pagprincipal.php"><img src="imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="pagprincipal.php">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="pagprodutos.php"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagservicos.php"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href="carrinho.php"><button class="butheader3"><img class="cbgheader" src="imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>
<main>
    <h1>Seu Carrinho</h1>
    <ul id="cart-items"></ul>
    <p><strong>Total: R$ <span id="total-price">0</span></strong></p>
    <button style="margin-bottom:20px; margin-top:20px; " id="buy-button" onclick="finalizePurchase()">Comprar</button>
</main>

    <script src="js/carrinho.js"></script>
</body>
</html>
