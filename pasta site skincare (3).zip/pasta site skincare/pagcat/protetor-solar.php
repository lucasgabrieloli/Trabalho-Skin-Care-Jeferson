<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../styles/style.css">
    <link rel="stylesheet" href="../styles/pagcat.css">
    <style>
            .preço {
                font-family: Arial, Helvetica, sans-serif;
                font-weight: 900;
                font-size: 18px;
                position: absolute;
                bottom: 10px;
                left: 45%; 
                transform: translateX(-50%);
            }
    </style>
</head>
<body>
<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="https://www.instagram.com/_.gabrielnunes_/">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="../imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="paglogin.php"><img style="height: 20px; width: 20px;" src="../imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="paglogin.php">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="../pagprincipal.php"><img src="../imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="../pagprincipal.php">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="../pagprodutos.php"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagservicos.php"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagrecomendacoes.php"><strong>RECOMENDAÇÕES</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href=""><button class="butheader3"><img class="cbgheader" src="../imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>
<div id="divcat">
    <div id="divBusca">
        <input type="text" id="txtBusca" placeholder="Procurar Produtos ou Serviços" />
        <img src="../imgs/search3.png" id="btnBusca" alt="Buscar" />
    </div>
</div>

    <h1>PROTETORES SOLARES</h1>

    <main>
    <div class="container">
        <div class="img-wraper">
            <a href="../pagvend/solar-oil-free-fps-50-creamy.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/psolar1creamy.png" alt="">
                <span>Solar Oil Free FPS 50 (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/sun-protection-fps-50-principia.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/psolar2principia.png" alt="">
                <span>Sun Protection FPS 50 (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/protetor-solar-fps-50-sallve.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/psolar3sallve.png" alt="">
                <span>Protetor Solar Facial FPS 50 (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/sun-discolor-fps-50-darrow.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/psolar4darrow.png" alt="">
                <span>Sun Discolor FPS 50 (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="../pagvend/protetor-solar-facial-matte-fps-50-eudora.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/hidratante5eudora.png" alt="">
                <span>Protetor Solar Facial Matte FPS 50 (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

    </div>
    </main>

    
</body>
</html>