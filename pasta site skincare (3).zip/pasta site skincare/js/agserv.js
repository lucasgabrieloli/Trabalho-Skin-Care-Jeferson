
const confirmarAgendamentoBtn = document.getElementById('confirmar-agendamento');
const dataInput = document.getElementById('data-agendamento');

function validarDataFutura(dataEscolhida) {
    const dataAtual = new Date();
    const dataSelecionada = new Date(dataEscolhida);
    return dataSelecionada > dataAtual;
}

confirmarAgendamentoBtn.addEventListener('click', function() {
    const dataEscolhida = dataInput.value;
    
    if (dataEscolhida) {
        if (!validarDataFutura(dataEscolhida)) {
            alert('Por favor, escolha uma data futura.');
        } else {
            alert(`Seu serviço foi agendado para ${dataEscolhida}, muito obrigada por comprar conosco!`);
        }
    } else {
        alert('Por favor, escolha uma data.');
    }
});
