function getCart() {
    const cart = localStorage.getItem('cart');
    return cart ? JSON.parse(cart) : [];
}

function saveCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function addToCart(productName, productPrice) {
    const cart = getCart();
    cart.push({ name: productName, price: productPrice });
    saveCart(cart);
    console.log('Carrinho atualizado:', cart);
    alert(`${productName} foi adicionado ao carrinho!`);
}


function displayCart() {
    const cart = getCart();
    console.log('Itens no carrinho:', cart);
    const cartItemsList = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');
    
    if (!cartItemsList || !totalPriceElement) return;

    cartItemsList.innerHTML = '';
    let totalPrice = 0;

    cart.forEach((item, index) => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - R$ ${item.price.toFixed(2)}`;

        const removeButton = document.createElement('button');
        removeButton.className = 'remove-button';
        removeButton.innerHTML = `<img src="imgs/icons8-lixo-24.png" alt="Remover">`;
        removeButton.onclick = () => removeFromCart(index);

        li.appendChild(removeButton);
        cartItemsList.appendChild(li);
        totalPrice += item.price;
    });

    totalPriceElement.textContent = totalPrice.toFixed(2); 
}


function removeFromCart(index) {
    const cart = getCart();
    cart.splice(index, 1); 
    saveCart(cart); 
    displayCart(); 
}

function finalizePurchase() {
    const cart = getCart();
    
    if (cart.length === 0) {
        alert('Seu carrinho está vazio! Adicione itens antes de comprar.');
        return;
    }

    alert('Obrigada por comprar conosco!');

    saveCart([]);
    displayCart();
}

document.addEventListener('DOMContentLoaded', displayCart);
