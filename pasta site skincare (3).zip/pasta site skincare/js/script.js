
const radios = document.querySelectorAll('input[name="radio-btn"]');
const slidesContainer = document.querySelector('.slides');

const slideWidth = 100; 
const autoSlideInterval = 5000; 
let currentIndex = 0;
let autoSlideTimer;

function updateSlider(index) {
  const offset = -index * slideWidth; 
  slidesContainer.style.transform = `translateX(${offset}%)`;
  radios[index].checked = true; 
  currentIndex = index; 
}


function startAutoSlide() {
  autoSlideTimer = setInterval(() => {
    let nextIndex = (currentIndex + 1) % radios.length; 
    updateSlider(nextIndex);
  }, autoSlideInterval);
}


function stopAutoSlide() {
  clearInterval(autoSlideTimer);
}

radios.forEach((radio, index) => {
  radio.addEventListener('click', () => {
    updateSlider(index); 
    stopAutoSlide(); 
    startAutoSlide(); 
  });
});


updateSlider(0);
startAutoSlide();
