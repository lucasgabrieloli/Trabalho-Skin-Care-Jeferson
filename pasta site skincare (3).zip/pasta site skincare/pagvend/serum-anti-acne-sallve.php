<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../styles/style.css">
    <link rel="stylesheet" href="../styles/pagvenda.css">
    <style>
                main{
            margin-top: 50px;
            margin-right: 400px;
            margin-left: 400px;
            display: flex;
            padding: 15px;
            margin-bottom: 50px;
            box-shadow: 6px 6px 6px rgba(0, 0, 0, 0.2);
            border-radius: 3px;
            background-color: #f39c9c36;
            overflow: hidden;
            border-radius: 20px;
            }

    </style>
</head>
<body>
<header>
    <p class="pheader" style="margin-left: 300px;">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-mensagem-preenchida-50.png" alt="">contato@brilhoeglamour.com&emsp;&emsp;|&emsp;&emsp;
        <a href="https://www.instagram.com/_.gabrielnunes_/">
            <img style="height: 20px; width: 20px; margin-right: 15px;" src="../imgs/icons8-insta-24.png" alt=""></a>
        <a href="">
            <img style="height: 20px; width: 20px;" src="../imgs/icons8-whatsapp-24.png" alt=""></a></p>
    <p class="pheader" style="margin-right: 300px">Seja bem-vindo ao nosso site!&emsp;&emsp;|&emsp;&emsp;
        <a style="text-decoration: none;" href="../logincad/index.html"><img style="height: 20px; width: 20px;" src="../imgs/icons8-pessoa-30.png" alt="">&emsp;<a style="font-weight: 600;" class="aheader" href="../logincad/index.html">ENTRAR</a></a></p>
</header>

<div class="header2">
    <a id="logo" href="pagprincipal.php"><img src="../imgs/logo.jpg" alt=""></a>
    <ul class="ulheader">
        <li>
            <a class="aheader2" href="../pagprincipal.php">INÍCIO</a> 
        </li>
        <li>
            <a class="aheader2" href="../pagprodutos.php"><strong>PRODUTOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagservicos.php"><strong>SERVIÇOS</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../contato.php"><strong>CONTATO</strong></a>
        </li>
        <li>
            <a class="aheader2" href="../pagsobrenos.php"><strong>SOBRE NÓS</strong></a>
        </li>
    </ul>

    <a class="aheader2" style="margin-right: 450px;" href="../carrinho.php"><button class="butheader3"><img class="cbgheader" src="../imgs/icons8-carrinho-50.png" alt=""></button></a>
</div>

    <main>
        <div class="ppv">
                <img class="imgv" src="../imgs/produtos/pele_oleosa/serum5sallve.png" alt=""> 
            <div class="titeprec">
                <h2>Sérum Anti-Acne (Sallve)</h2>
                <h3>R$10,00</h3>
                    <div class="listra"></div>
                <!--ADICIONAR BOTAO AQ PARA CARRINHO OU PRA COMPRA-->
                <div class="divbotao">
                <button onclick="addToCart('Sérum Anti-Acne (Sallve)', 10)">Adicionar ao carrinho</button>
                </div>
            </div>            
        </div>
            
            <div class="infoprod">
                <h2 id="titt">Mais informações sobre o produto</h2>
                <h3 id="titt2"> O Sérum Antiacne da Sallve é uma solução poderosa para peles oleosas e com tendência à acne. Formulado com ácido salicílico, niacinamida e óleo de melaleuca, ele combate cravos e espinhas, controla a oleosidade e acalma a pele. Sua textura leve e de rápida absorção deixa a pele com um acabamento seco e uniforme, sem obstruir os poros.
                </h3>
            </div>

            <h2 id="mprod">MAIS PRODUTOS</h2>

        <div class="container">
        <div class="img-wraper">
            <a href="pagvend/gel-limpeza-skin-100g-eudora.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial1eudorapo.jpg" alt="">
                <span>Gel de Limpeza Skin 100g (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial2darrowpo.png" alt="">
                <span>Actine Sabonete Líquido + Vit C - Laranja 240g (Darrow)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial3principiapo.png" alt="">
                <span>Gel de Limpeza 2% Ácido Salicílico + 5% Glicerina 350g (Principia)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial4creamypo.png" alt="">
                <span>Gel de limpeza suave antioleosidade 100ml (Creamy)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>

        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/produtos/pele_oleosa/sbfacial5sallvepo.png" alt="">
                <span>Limpador antioleosidade 300 ml (Sallve)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>
        <div class="img-wraper">
            <a href="pagcompra.php">
                <img class="imgprod" src="../imgs/produtos/pele_mista/sbfacial1eudora.png" alt="">
                <span>Dermo Hidratante (Eudora)</span>
                <span class="preço">R$10,00</span>
            </a>
        </div>


    </main>

    
    <script src="../js/carrinho.js"></script>
</body>
</html>